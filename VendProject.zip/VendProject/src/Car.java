import uk.admiral.vending.model.vendingmachine.stockmanager.IVendable;


public class Car implements IVendable {

	private String Description = "";

	public Car(String Colour, String Make, String Model){	
		Description = Colour + " " + Make + " " + Model;
	}
	
	@Override
	public String getDescription() {
		return Description;
	}


}
