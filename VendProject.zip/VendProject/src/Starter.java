import uk.admiral.vending.model.example.ExampleProduct;
import uk.admiral.vending.model.vendingmachine.VendingMachine;
import uk.admiral.vending.model.vendingmachine.VendingMachineException;
import uk.admiral.vending.model.vendingmachine.coinmanager.Coin;
import uk.admiral.vending.model.vendingmachine.coinmanager.Coin.CoinTypes;
import uk.admiral.vending.model.vendingmachine.stockmanager.IVendable;

public class Starter {

	public static void main(String[] args) {
		

		VendingMachine mach = initialiseVendingMachine();
		
		//# insert a 50p piece
		mach.insertCoin(new Coin(CoinTypes.FIFTY));
		
		//# attempt to Vend a hat
		attemptToVend(mach, 0, 0);
		
		//# attempt to vend a t-shirt
		attemptToVend(mach, 0, 1);
		
		//# insert a 50p piece
		mach.insertCoin(new Coin(CoinTypes.FIFTY));
		mach.insertCoin(new Coin(CoinTypes.ONE));
		mach.insertCoin(new Coin(CoinTypes.FIFTY));
		mach.insertCoin(new Coin(CoinTypes.TWENTY));
		
		//# attempt to vend a t-shirt
		attemptToVend(mach, 0, 1);
		
		mach.retrieveCoinsFromChangeTray();
		
		//# insert a 50p piece
		mach.insertCoin(new Coin(CoinTypes.FIFTY));
		mach.insertCoin(new Coin(CoinTypes.FIFTY));
		
		//# attempt to vend a t-shirt
		attemptToVend(mach, 0, 2);

	}
	
	
	//# Initialise and restock a vending machine
	private static VendingMachine initialiseVendingMachine(){
		

		System.out.println("----  Starting Vending Machine creation ---- \r\n");
		
		//# Initialise and load the vending machine
		VendingMachine mach = new VendingMachine(10, 10);
		
		//# re-stocking change
		mach.restockChange(CoinTypes.FIFTY, 50);
		mach.restockChange(CoinTypes.TEN, 50);
		mach.restockChange(CoinTypes.POUND, 50);
		mach.restockChange(CoinTypes.ONE, 100);
		
	
		
		//# re-stocking products
		try {
			mach.restockProductAtLocation(0, 0, new ExampleProduct("Hat"), 2, 1.00);
			mach.restockProductAtLocation(0, 1, new ExampleProduct("T-Shirt"), 2, 0.50);
			mach.restockProductAtLocation(0, 2, new Car("Blue", "Ford", "Ka"), 1, 1.00);
			mach.restockProductAtLocation(0, 12, new ExampleProduct("Fail Product"), 2, 1.00);
		} catch (VendingMachineException e) {
			System.out.println("-- Failed - " + e.getMessage());
		}

		
		System.out.println("\r\n----  Ending Vending Machine creation ---- \r\n");
	
		return mach;
	}
	
	//# helper method for vending items from the vending machine
	private static IVendable attemptToVend(VendingMachine vend, int Positionx, int PositionY){
		try {
			IVendable prod = vend.attemptToVendProduct(Positionx, PositionY);
		} catch (VendingMachineException e) {
			System.out.println("-- Failed - " + e.getMessage());
		} 
		
		return null;
	}
}
